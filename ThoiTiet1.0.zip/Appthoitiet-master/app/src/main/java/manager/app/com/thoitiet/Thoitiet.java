package manager.app.com.thoitiet;

public class Thoitiet {
    public String Ngay;
    public String TrangThai;
    public String Anh;
    public String CaoNhat;
    public String ThapNhat;

    public Thoitiet(String ngay, String trangThai, String anh, String caoNhat, String thapNhat) {
        Ngay = ngay;
        TrangThai = trangThai;
        Anh = anh;
        CaoNhat = caoNhat;
        ThapNhat = thapNhat;
    }
}
